/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author SittiHajra
 */
public class MenghitungKelilingJajargenjang {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int keliling, a, b;
        
        System.out.print("Inputkan nilai a =");
        a = Integer.parseInt(scan.nextLine());
        
        System.out.print("Inputkan nilai b =");
        b = Integer.parseInt(scan.nextLine());
        
        keliling = 2*a+2*b;
        System.out.println("Hasil keliling jajar genjang ="+keliling);
}

}