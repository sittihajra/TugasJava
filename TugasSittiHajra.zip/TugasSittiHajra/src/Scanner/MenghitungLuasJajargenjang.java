/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author SittiHajra
 */
public class MenghitungLuasJajargenjang {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int luas, alas, tinggi;
        
        System.out.print("Inputkan nilai alas =");
        alas = Integer.parseInt(scan.nextLine());
        
        System.out.print("Inputkan nilai tinggi =");
        tinggi = Integer.parseInt(scan.nextLine());
        
        luas = alas*tinggi;
        System.out.println("Hasil luas jajar genjang ="+luas);
}

}