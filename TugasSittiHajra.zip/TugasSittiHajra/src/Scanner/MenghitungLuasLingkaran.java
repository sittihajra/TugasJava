/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author SittiHajra
 */
public class MenghitungLuasLingkaran {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        double luas, radius;
        
        System.out.print("Inputkan nilai radius=");
        radius = Double.valueOf(scan.nextLine());
        
        luas = 3.14*radius*radius;
        System.out.println("Hasil luas lingkaran ="+luas);
    }
}
