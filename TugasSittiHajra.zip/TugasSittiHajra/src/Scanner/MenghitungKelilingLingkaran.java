/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author SittiHajra
 */
public class MenghitungKelilingLingkaran {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        double keliling, radius;
        
        System.out.print("Inputkan nilai radius=");
        radius = Double.valueOf(scan.nextLine());
        
        keliling = 2*3.14*radius;
        System.out.println("Hasil keliling lingkaran ="+keliling);
        
        
}

}