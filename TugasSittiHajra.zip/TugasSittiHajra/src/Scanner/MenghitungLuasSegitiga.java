/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author SittiHajra
 */
public class MenghitungLuasSegitiga {
    public static void main(String[]args){
     Scanner scan = new Scanner(System.in);
     double luas, a, t;
     
     System.out.print("Inputkan nilai a =");
     a = Double.valueOf(scan.nextLine());
     
     System.out.print("Inputkan nilai t =");
     t = Double.valueOf(scan.nextLine());
     
     luas = 0.1/0.2*a*t;
     System.out.println("Hasil luas segitiga ="+luas);
}

}