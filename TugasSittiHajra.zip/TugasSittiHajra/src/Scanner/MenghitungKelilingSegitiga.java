/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author SittiHajra
 */
public class MenghitungKelilingSegitiga {
    public static void main(String[]args){
     Scanner scan = new Scanner(System.in);
     int keliling, a, b, c;
     
     System.out.print("Inputkan nilai a =");
     a = Integer.parseInt(scan.nextLine());
     
     System.out.print("Inputkan nilai b =");
     b = Integer.parseInt(scan.nextLine());
     
     System.out.print("Inputkan nilai c =");
     c = Integer.parseInt(scan.nextLine());
     
     keliling = a+b+c;
     System.out.println("Hasil keliling segitiga ="+keliling);
}

}