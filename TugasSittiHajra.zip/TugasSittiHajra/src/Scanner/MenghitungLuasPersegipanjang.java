/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author SittiHajra
 */
public class MenghitungLuasPersegipanjang {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int luas, panjang, lebar;
        
        System.out.print("Inputkan nilai panjang =");
        panjang = Integer.parseInt(scan.nextLine());
        
        System.out.print("Inputkan nilai lebar =");
        lebar = Integer.parseInt(scan.nextLine());
        
        luas = panjang*lebar;
        System.out.println("Hasil luas persegi panjang ="+luas);
}


}